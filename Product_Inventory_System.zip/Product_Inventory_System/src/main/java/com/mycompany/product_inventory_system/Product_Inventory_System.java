/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.product_inventory_system;

/**
 *
 * @author KR1
 */
public class Product_Inventory_System {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
